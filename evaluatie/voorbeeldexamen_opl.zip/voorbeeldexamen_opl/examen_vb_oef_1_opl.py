""" Oefening 1 (   / 8)
Deze oefening bestaat uit 3 niveaus, die je afzonderlijk kan maken. 
Niveau 1 & 2 maken enkel gebruik van de dictionary examen.
Niveau 3 maakt ook gebruik van de lijst deelnemers.

Tip! Als je met een bepaald niveau bezig bent, zet de code van de andere niveaus in commentaar. 
     Dit voorkomt fouten en zorgt dat je alleen aan de code werkt die relevant is.

"""
# Dictionary bevat alle deelnemers die het examen afgelegd hebben, met hun score.
# Sleutel = Naam leerling, Waarde = Score leerling (op 100).
examen = { 
    "Jan": 75,
    "Piet": 59
}

# Lijst bevat alle deelnemers die het examen afleggen.
deelnemers = ["Jan", "Joris", "Piet", "Korneel"]

""" Niveau 1 (   / 2)
Stel een overzicht op met erin iedere leerling die het examen reeds heeft afgelegd (zie examen).
Het overzicht moet eruit zien zoals onderstaand voorbeeld.

De code moet blijven werken ook als de inhoud van examen wijzigt.
Test dit zelf uit door manueel elementen eraan toe te voegen of te verwijderen.

VOORBEELD
---------
Overzicht van examenresultaten...
    - Jan heeft een score van 75/100.
    - Piet heeft een score van 59/100.
"""

# print("Overzicht van examenresultaten...")
# for deelnemer, score in examen.items():
#     print(f"    - {deelnemer} heeft een score van {score}/100.")

""" Niveau 2 (    / 3)
Print volgende informatie over de dictionary examen:
    - Hoeveel deelnemers het examen reeds hebben afgelegd.
    - De deelnemer die de hoogste score heeft gehaald (en welke score)
    - De gemiddelde score van alle deelnemers samen.

De code moet blijven werken ook als de inhoud van examen wijzigt.
Test dit zelf uit door manueel elementen eraan toe te voegen of te verwijderen.

VOORBEELD
---------
Info over examen...
    - 2 deelnemers heeft het examen reeds afgelegd.
    - Jan heeft het hoogste resultaat (75/100).
    - Het examen heeft een gemiddelde score van 67.0/100.
"""

# # Bepalen van hoogste score & gemiddelde score.
# hoogste_deelnemer, hoogste_score = "", -1
# som_scores = 0
# for deelnemer, score in examen.items():
#     som_scores = som_scores + score
#     if score > hoogste_score:
#         hoogste_score = score
#         hoogste_deelnemer = deelnemer
# gem_score = som_scores/len(examen)

# # Printen van gevraagde info.
# print("Info over examen...")
# print(f"    - {len(examen)} deelnemers heeft het examen reeds afgelegd.")
# print(f"    - {hoogste_deelnemer} heeft het hoogste resultaat ({hoogste_score}/100).")
# print(f"    - Het examen heeft een gemiddelde score van {gem_score}/100.")


""" Niveau 3 (   / 3)
Overloop de lijst met deelnemers. 

Heeft deze deelnemer het examen reeds afgelegd?
    Print dan: *naam* heeft het examen reeds afgelegd.

Heeft deze deelnemer het examen NIET afgelegd?
    Genereer dan een random score tussen 0 en 100.
    Print dan: *naam* heeft een score van *random*/100 gehaald.
    Voeg tenslotte de deelnemer toe aan de dictionary examen met deze score.

Print op het einde de aangevulde dictionary.
   
VOORBEELD
---------
Examen overlopen...
    - Jan heeft het examen reeds afgelegd.
    - Joris heeft een score van 98/100 gehaald.
    - Piet heeft het examen reeds afgelegd.
    - Korneel heeft een score van 87/100 gehaald.

Eindresultaat examen...
{'Jan': 75, 'Piet': 59, 'Joris': 98, 'Korneel': 87}
"""
# import random

# print("Examen overlopen...")
# for deelnemer in deelnemers:
#     if deelnemer in examen:
#         print(f"    - {deelnemer} heeft het examen reeds afgelegd.")
#     else:
#         score = random.randint(0,100)
#         print(f"    - {deelnemer} heeft een score van {score}/100 gehaald.")
#         examen[deelnemer] = score

# print(f"\nEindresultaat examen...")
# print(examen)